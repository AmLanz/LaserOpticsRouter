"""LaserOpticsRouter package."""
