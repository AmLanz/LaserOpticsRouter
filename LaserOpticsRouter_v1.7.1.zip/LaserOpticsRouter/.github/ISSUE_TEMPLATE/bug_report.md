---
name: Bug report
about: Report a reproducible layout, interface or Fusion integration problem
title: ''
labels: ''
assignees: ''
---

**Environment**
- LaserOpticsRouter version:
- Fusion version and operating system:
- Document intent: Part / Assembly / Hybrid / legacy
- Modeling mode: parametric / direct

**Minimal route and steps to reproduce**
```text
Paste the smallest command sequence that reproduces the problem.
```

**Expected / actual behavior**

**For component placement**
Source type (local / linked), datum, local axes, calibration and whether the
issue occurs in planning, selected-CAD preview, full preview or build:

**Diagnostic log / screenshot**
Remove private paths, component names and project details before posting.
